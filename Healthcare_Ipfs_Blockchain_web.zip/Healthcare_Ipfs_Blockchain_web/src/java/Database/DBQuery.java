package Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DBQuery {

    public Connection con = null;
    public Statement st = null;
    public ResultSet rs = null;
    private String name;
    private String email;
    private String phone;
    private String add;
    private String state;
    private String city;
    
    private String uname;
    private String h_id;
    private String hname;
    private String ph_no;
    private String mc_id;
    private String mn_name;
    private String mc_add;
    private String pass;
    private String q;
    private String password;
    private String utype;
    private ResultSet d;

    public int addhospData(int id, String name, String email, int phone, String area, String add, String state, String city, int lon, int lat, String password) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String q1 = "insert into hospital_list values ('" + id + "','" + name + "','" + email + "','" + phone + "','" + area + "','" + add + "','" + state + "','" + city + "','" + lon + "','" + lat + "')";
        System.out.println(">>" + q1);
        st = con.createStatement();
        String q = "insert into login values('" + email + "','" + password + "','hospital')";
        System.out.println("" + q1);
        i = st.executeUpdate(q1);
        st.executeUpdate(q);
        return i;
    }
 public int add_lab_assistance(String hid,String fname,String lname,  String phone, String pass,String email) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String q1 = "insert into lab_assistant_details set hid='"+hid+"', fname='" + fname + "',lname='" + lname + "',mobile='" + phone + "', pass='"+pass+"',email='"+email+"'";
        System.out.println(">>" + q1);
        st = con.createStatement();
        String q = "insert into login values('" + phone + "','" + pass + "','lab_assitant')";
        System.out.println("" + q1);
        i = st.executeUpdate(q1);
        st.executeUpdate(q);
        return i;
    }


public ResultSet get_patient_details(String aadhar) throws ClassNotFoundException, SQLException{
         
        
       
        String qry2 = "select * from patient_registration where aadhar='"+aadhar+"'";
          
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          rs = st.executeQuery(qry2);
          
          
          
          
          return rs;
    }
    

    public int addUserData(String aadhar,String hid,String fname, String lname, String phone,String email, String add, String doctorID, String group, String admDate,  String password) throws SQLException, ClassNotFoundException {
       
        
        int i = 0;
        try{
        
        con = DBConnection.getConnection();
        String p = "insert into patient_registration(aadhar,hid,fname, lname, phone_no,email, address, consulting_doctor_id, blood_group, admission_date,  password) values ('"+aadhar+"','"+hid+"','"
                 + fname + "','" + lname + "','" + phone + "','"+email+"','" + add + "','" + doctorID + "','" + group + "','" +admDate+"' ,'" + password + "')";
        System.out.println(">>" + p);
        st = con.createStatement();
        //String l = "insert into login values('" + email + "','" + password + "','user')";
        //System.out.println("" + p);
        i = st.executeUpdate(p);
        String q1="select MAX(patient_id) from patient_registration";
        System.out.println(">>"+q1);
        rs=st.executeQuery(q1);
        if(rs.next())
        {
        i=rs.getInt(1);
        
        }
        //st.executeUpdate(l);
        
    }catch(Exception e)
    {
    e.printStackTrace();
    }
        return i;
    }
    

    

    public int addMedicines(String medicine_Name, int amount, int quantity) throws ClassNotFoundException, SQLException{
        int i = 0;
        con = DBConnection.getConnection();
        String qry = "insert into medicine_info(medicine_name, price, quantity_available) values('" + medicine_Name + "','" + amount + "','" + quantity + "')";
        st = con.createStatement();
        i = st.executeUpdate(qry);
        return i;
    }
    

    public ArrayList[] get_doctors_info() throws ClassNotFoundException, SQLException{
        ArrayList al_ids=new ArrayList();
        ArrayList al_names=new ArrayList();
        ArrayList al_emails=new ArrayList();
        
        ArrayList al_mob=new ArrayList();
        ArrayList al[]=new ArrayList[4];
       
        String qry2 = "select * from doctor_reg";
         
          
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al_ids.add(rs2.getInt("doctor_id"));
             al_names.add(rs2.getString("fname")+" "+rs2.getString("lname"));
             al_emails.add(rs2.getString("email_id"));
             al_mob.add(rs2.getString("mobile_no"));
          }
          al[0]=al_ids;
          al[1]=al_names;
          al[2]=al_emails;
          al[3]=al_mob;
          return al;
    }
    public ArrayList[] get_lab_assistant_info() throws ClassNotFoundException, SQLException{
        ArrayList al_id=new ArrayList();
        ArrayList al_fnames=new ArrayList();
        ArrayList al_lnames=new ArrayList();
        ArrayList al_emails=new ArrayList();
        
        ArrayList al_mob=new ArrayList();
        ArrayList al[]=new ArrayList[5];
       
        String qry2 = "select * from lab_assistant_details";
         
          
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al_id.add(rs2.getString("id"));
             al_fnames.add(rs2.getString("fname"));
             al_lnames.add(rs2.getString("lname"));
             al_emails.add(rs2.getString("email"));
             al_mob.add(rs2.getString("mob"));
          }
          al[0]=al_id;
          al[1]=al_fnames;
          al[2]=al_lnames;
          al[3]=al_emails;
          al[4]=al_mob;
          return al;
    }
    
    


    
    public int getLabTestCount() throws ClassNotFoundException, SQLException{
        String qry = "select count(*) from lab_test_registration";
        int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
        
          return count;
    }

    
    public int docReg(String hid,String fname, String lname, String email, String mobNo, String gender, String addr, String qlf, String password) throws ClassNotFoundException, SQLException{
        int i = 0;
        String qry = "insert into doctor_reg(hid,fname, lname, email_id, mobile_no, gender, address, qualifications, password) values('"+hid+"','" + fname + "','" + lname + "','" + email + "','" + mobNo + "','" + gender + "','" + addr + "','" + qlf + "','" + password + "')";
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        return i;
    }
     public int add_hospital(String hname, String email, String mob,  String addr, String pass) throws ClassNotFoundException, SQLException{
        int i = 0;
        String qry = "insert into hospital_details set hname='"+hname+"', email='"+email+"', mob='"+mob+"',address='"+addr+"'";
      
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        int hid=get_max_hid();
         System.out.println("hid="+hid);
        String qry1= "insert into login values('"+hid+"','"+pass+"', 'hospital')";
        st.executeUpdate(qry1);
        return hid;
    }
      public int get_max_hid() throws ClassNotFoundException, SQLException{
        
        String qry1 = "select MAX(hid) from hospital_details";
       
          int id = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              id = rs1.getInt(1);
          }
       
          
          return id;
    }
    public int[] getDocIds(String hid) throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from doctor_reg where hid='"+hid+"'";
        String qry2 = "select doctor_id from doctor_reg where hid='"+hid+"'";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] docIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getInt("doctor_id");
          }
          
          return docIDArr;
    }
     public String[] getDocNames(String hid) throws ClassNotFoundException, SQLException{
         
        
        String qry1 = "select count(*) from doctor_reg where hid='"+hid+"'";
        String qry2 = "select * from doctor_reg where hid='"+hid+"'";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          String[] docIDArr = new String[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getString("fname")+" "+rs2.getString("lname");
          }
          
          return docIDArr;
    }
    public int[] getPatIds(String did) throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from patient_registration where consulting_doctor_id like '%"+did+"%'";
        String qry2 = "select patient_id from patient_registration where consulting_doctor_id like '%"+did+"%'";
        System.out.println(qry2);
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] docIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getInt("patient_id");
          }
          System.out.println(".."+docIDArr.length);
          return docIDArr;
    }
    public int[] getPatIds() throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from patient_registration";
        String qry2 = "select patient_id from patient_registration";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] docIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getInt("patient_id");
          }
          
          return docIDArr;
    }
    public int[] getLabTestIDs() throws ClassNotFoundException, SQLException{
        String qry1 = "select count(*) from lab_test_registration";
        String qry2 = "select lab_test_id from lab_test_registration";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] labTestArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              labTestArr[k++] = rs2.getInt("lab_test_id");
          }
          
          return labTestArr;
    }

 
    public String validatePass(String id, String pass) throws ClassNotFoundException, SQLException{
        String qry = "select * from doctor_reg where doctor_id =  '"+id+"'  and password='"+pass+"'";
        System.out.println("****"+qry);
        con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
          String hid="";
          int res = 0;
          
          if(rs.next()){
             
              
              hid = rs.getString("hid");
          }
          rs.close();
          
          
          
          return hid;
    }
    public String validate_patient(String id, String pass) throws ClassNotFoundException, SQLException{
        String qry = "select * from patient_registration where patient_id =  '"+id+"'  and password='"+pass+"'";
        System.out.println("****"+qry);
        con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
          String hid="";
          int res = 0;
          
          if(rs.next()){
             
              
              hid = rs.getString("hid");
          }
          rs.close();
          
          
          
          return hid;
    }
    public int[] getPatientInfo(int doc_id) throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from patient_registration where consulting_doctor_id = " + doc_id;
        String qry2 = "select patient_id from patient_registration where consulting_doctor_id = " + doc_id;
        
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] patientIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              patientIDArr[k++] = rs2.getInt("patient_id");
          }
          
          return patientIDArr; 
    }
    
    public String[] getPatientRep(String hid,String patient_id) throws ClassNotFoundException, SQLException{
       
        String qry = "select * from patient_registration where hid='"+hid+"' and patient_id = " + patient_id;
        
          con = DBConnection.getConnection();
           st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
          
          String name      = "";
          String phone_no = "";
          String email     = "";
          String bloodGrp  = "";
          String admDate   = "";
       
          
          while(rs.next()){
              String fname = rs.getString("fname");
              String lname = rs.getString("lname");
              name  = fname + " " + lname;
              phone_no  = rs.getString("phone_no");
              email  = rs.getString("email");
              bloodGrp  = rs.getString("blood_group");
              admDate  = rs.getString("admission_date");
           
          }
          rs.close();
          
          String[] patientRep = {name,phone_no,email, bloodGrp,  admDate}; 
          return patientRep;
    }
    
    public String getDoctorName(int docID) throws ClassNotFoundException, SQLException{
        String qry = "select fname, lname from doctor_reg where doctor_id = " + docID;
        
        con = DBConnection.getConnection();
           st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
           String name = "";
          
          while(rs.next()){
              String fname = rs.getString("fname");
              String lname = rs.getString("lname");
              name = fname + " " + lname;
          }
          rs.close();
          return name;
    }
    
    public int add_report_details(String hid,String pid, String rid, String uploaded_by, String emp_id,String dtime) throws ClassNotFoundException, SQLException{
        int i = 0;
        
        String qry = "insert into report_details values ('" + hid + "','" + pid + "','" + rid + "','" + uploaded_by + "','" + emp_id + "','" + dtime + "')";   
        System.out.println(qry);
          con = DBConnection.getConnection();
           st = con.createStatement();
            i = st.executeUpdate(qry);
           
            return i;
    }
     
     
     
     // **
    public String loginCheck(String email, String password) throws SQLException, ClassNotFoundException {
        String i = "";//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select utype from login where user_id='" + email + "' and password='" + password + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        while (rs.next()) {
            i = rs.getString("utype");
        }
        return i;
    }
     public String get_hid(String lab) throws SQLException, ClassNotFoundException {
        String i = "";//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select hid from lab_assistant_details where mobile='" + lab + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        while (rs.next()) {
            i = rs.getString("hid");
        }
        return i;
    }
   public int PloginCheck(String pid, String password) throws SQLException, ClassNotFoundException {
        int i = 0;//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select * from patient_registration  where patient_id='" + pid + "' and password='" + password + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        if (rs.next()) {
            i=1;
        }
        return i;
    }


    public ResultSet get_hospital_area(String area) throws ClassNotFoundException, SQLException {
        ArrayList al = new ArrayList();

        con = DBConnection.getConnection();
        String l = "select * from hospital_list where area='" + area + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        return rs;
    }

    public String get_hospital_list(String area) throws ClassNotFoundException, SQLException {
        ArrayList al = new ArrayList();
        String d = "";
        con = DBConnection.getConnection();
        String l = "select * from hospital_list where area='" + area + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        while (rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("name");
            String email = rs.getString("email");
            String phone = rs.getString("phone");
            String areas = rs.getString("area");
            String add = rs.getString("add");
            String state = rs.getString("state");
            String city = rs.getString("city");
            String lon = rs.getString("lon");
            String lat = rs.getString("lat");


            d += id + "-" + name + "-" + email + "-" + phone + "-" + areas + "-" + add + "-" + state + "-" + city + "-" + lon + "-" + lat + "##";

        }

        return d;
    }


    public int getIdOfHospital(String usermailid) throws ClassNotFoundException, SQLException {
        int i = 0;

        con = DBConnection.getConnection();
        String l = "select * from hospital_list where email='" + usermailid + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        if (rs.next()) {
            i = rs.getInt("id");
        }
        System.out.println("Id for hospital--" + i);
        return i;
    }

public ArrayList get_pid_list(String hid) throws ClassNotFoundException, SQLException {
        int i = 0;
        ArrayList al=new ArrayList();

        con = DBConnection.getConnection();
        String l = "select * from patient_registration where hid='" + hid + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        while (rs.next()) {
            i = rs.getInt("patient_id");
            al.add(i);
        }
        System.out.println("Id for hospital--" + i);
        return al;
    }
 public ArrayList get_patient_details(String hid,String pid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from patient_registration where hid='"+hid+"' and patient_id='"+pid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          if(rs2.next()){
             al.add(rs2.getString("fname"));
             al.add(rs2.getString("lname"));
             al.add(rs2.getString("phone_no"));
             al.add(rs2.getString("email"));
             al.add(rs2.getString("address"));
             al.add(rs2.getString("consulting_doctor_id"));
             al.add(rs2.getString("blood_group"));
             al.add(rs2.getString("admission_date"));
             al.add(rs2.getString("email"));
             
             
          }
          
          return al;
    }
 
 
 public ArrayList get_my_details(String hid,String pid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from report_details where hid='"+hid+"' and pid='"+pid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getString("report_id")+"##"+rs2.getString("uploaded_by")+"##"+rs2.getString("emp_id")+"##"+rs2.getString("upload_date"));
             
            
             
             
          }
          
          return al;
    }
 public int add_request(String hid, String did, String pid, String rid) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String q1 = "insert into key_request values ('" + hid + "','" + did + "','" + pid + "','" + rid + "')";
        System.out.println(">>" + q1);
        st = con.createStatement();
        
        st.executeUpdate(q1);
        return i;
    }
 public ArrayList get_my_key_request(String hid,String pid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from key_request where hid='"+hid+"' and pid='"+pid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          if(rs2.next()){
             al.add(rs2.getString("hid")+"##"+rs2.getString("did")+"##"+rs2.getString("rid"));
             
            
             
             
          }
          
          return al;
    }
 public ArrayList get_doc_details(String hid,String did) throws ClassNotFoundException, SQLException {
        int i = 0;
        ArrayList al=new ArrayList();

        con = DBConnection.getConnection();
        String l = "select * from doctor_reg where hid='" + hid + "' and doctor_id='"+did+"'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        while (rs.next()) {
            
            al.add(rs.getString("fname"));
            al.add(rs.getString("lname"));
            al.add(rs.getString("email_id"));
            al.add(rs.getString("mobile_no"));
        }
       
        return al;
    }
}
