/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Database.DBQuery;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Sumit
 */
public class labRegistration extends HttpServlet {
private String fname="",lname="",phone="",password="",email="";
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            try{
            response.setContentType("text/html;charset=UTF-8");
        
      
        
        
    
        HttpSession session = request.getSession();
        RequestDispatcher rd = null;
        //String id = request.getParameter("u_id");
         fname    = request.getParameter("txtFname").toString();
        System.out.println("Patient FName = " + fname);
        
         lname    = request.getParameter("txtLname").toString();
        System.out.println("Patient LName = " + lname);
        
         phone    = request.getParameter("txtPhone").toString();
        System.out.println("Patient Phone Number = " + phone);
        
      
        
         password = request.getParameter("txtPass").toString();
         email = request.getParameter("txtEmail").toString();
        
        
        
        String uid=session.getAttribute("uname").toString();
        DBQuery db = new DBQuery();

        int i = db.add_lab_assistance(uid,fname, lname, phone, password,email);//doc_id

        if(i==1){
           
           session.setAttribute("msg", "Lab Assistant ID is "+i);
                System.out.println("Added Successful");
                rd=request.getRequestDispatcher("hospital_home.jsp");
                rd.forward(request, response);
        }
        
        else{
            session.setAttribute("msg", "Lab Assistant Registration Not Successful");
           rd=request.getRequestDispatcher("hospital_home.jsp");
                rd.forward(request, response);
        }
        
       
    }catch(Exception e)
    {
        e.printStackTrace();
    }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
