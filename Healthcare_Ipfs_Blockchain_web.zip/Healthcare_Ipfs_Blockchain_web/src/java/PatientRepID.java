/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import Database.DBQuery;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author sumit
 */
public class PatientRepID extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
             String id = request.getParameter("lstPatientID");
               String docID = request.getParameter("txtDocID");
                   int dcID = Integer.parseInt(docID);
              int patientID = Integer.parseInt(id);
              DBQuery db = new DBQuery();
             
//              String[] patientRep = db.getPatientRep(patientID);
//                   String docName = db.getDoctorName(dcID); 
//             
//              String name      = patientRep[0];
//              String bldGrp    = patientRep[1];
//             // String medicines = patientRep[2];
//            //  String tests     = patientRep[3];  
//              String admDate   = patientRep[2];
//            //  String billDate  = patientRep[5];
//             
//              response.sendRedirect("PatientRep.jsp?name=" + name + "&bloodGroup=" + bldGrp  + "&admission_date=" + admDate + "&docID=" + dcID + "&docName=" + docName + "&patientID=" + patientID);
//             
        } catch (Exception ex) {
            Logger.getLogger(PatientRepID.class.getName()).log(Level.SEVERE, null, ex);
        }  finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
