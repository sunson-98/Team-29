
import Database.DBQuery;
import Logic.info;


import com.oreilly.servlet.MultipartRequest;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.stream.FileImageInputStream;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "PatientRep", urlPatterns = {"/PatientRep"})
public class PatientRep extends HttpServlet {

    public String docId = "";
    public String patientID = "";
    public String path;
    public String docName = "";
    public String params = "";
    public String patientName = "";
    public String bloodGrp = "";
    public String medicines = "";
    public String labTests = "";
    public String visitDate = "";
    public String description = "";
    public String fileName = "aa.txt";
    public String filePath = info.path;//"D:/2018_Projects/Intrution/Hospital_MdB/build/web";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        System.out.println(">>>>>>>>>>>>checking");

    
            try {
                System.out.println("filePath="+filePath);
              //  MultipartRequest mpr = new MultipartRequest(request, filePath);
                 docId = request.getParameter("txtDocID");
                
                 docName = request.getParameter("txtDocName");
                 patientID = request.getParameter("txtPatientID");
                  fileName=docId+"-"+patientID+".txt";
                 patientName = request.getParameter("txtName");
               //  patientID = request.getParameter("txtPatientID");
                 bloodGrp = request.getParameter("txtBloodGrp");
                // medicines = request.getParameter("txtMedicines");
                // labTests = request.getParameter("txtLabTests");
                 visitDate = request.getParameter("txtVisitDate");
                 description = request.getParameter("txtArDescription");
                System.out.println("Doctor "+docId+" is checking patient "+patientID);
                  File f = new File(filePath + File.separator + fileName);
                  FileOutputStream fout=new FileOutputStream(f);
                  fout.write(description.getBytes());
                  fout.close();
                 
              

                String patientDetails = "Doctor ID = " + docId;
                patientDetails += "\nDoctor Name = " + docName;
                patientDetails += "\nPatient ID = " + patientID;
                patientDetails += "\nBlood Group = " + bloodGrp;
               // patientDetails += "\nMedicines = " + medicines;
            //    patientDetails += "\nLab Tests = " + labTests;
            //    patientDetails += "\nVisit Date = " + visitDate;
                patientDetails += "\nDescription = " + description;

                String path1 = "C://DoctorInfo/DocID-" + docId; //+ "/PatientID-" + patientID + "VisitDate-" + visitDate;
                int res = 0;
//            DBQuery db = new DBQuery();
//               res = db.insertReport(Integer.parseInt(docId), docName, Integer.parseInt(patientID), patientName, bloodGrp, medicines, labTests, visitDate, description);
//               System.out.println("Rows Updated = " + res);
//               if(res>0){
//                   System.out.println("Report Successfully Inserted!");
//               }
//               
//               else{
//                   System.out.println("Report Insertion failed!");
//               }

                File f1 = new File(path1);

                if (!f1.exists()) {
                    f1.mkdir();
                }

                String path2 = "C://DoctorInfo/DocID-" + docId + "/PatientID-" + patientID;

                File f2 = new File(path2);

                if (!f2.exists()) {
                    f2.mkdir();
                }

                String path3 = "C://DoctorInfo/DocID-" + docId + "/PatientID-" + patientID + "/VisitDate-" + visitDate;

                File f3 = new File(path3);

                if (!f3.exists()) {
                    f3.mkdir();
                }

                String path4 = path3 + "/PatientReport.txt";
                File f4 = new File(path4);

                if (!f4.exists()) {
                    f4.createNewFile();
                }

                FileOutputStream fout1 = new FileOutputStream(f4);
                fout1.write(patientDetails.getBytes());

                File f11 = new File(filePath + File.separator + fileName);
                FileInputStream fis = new FileInputStream(f11);
                int i = 0;
                String str = "";

                while ((i = fis.read()) != -1) {
                    char a = (char) i;
                    str += String.valueOf(a);
                }


                FileOutputStream fout12 = new FileOutputStream(path3 + "/" + fileName);
                fout12.write(str.getBytes());
                fout12.close();
                response.sendRedirect("patient_rep_ID.jsp?doc_id=" + docId);
//                RequestDispatcher rd = null;
//                rd = request.getRequestDispatcher("detailsConformation.jsp");
//                rd.forward(request, response);
               // response.sendRedirect("detailsConformation.jsp");

            }catch(Exception e)
            {
            e.printStackTrace();
            }finally {
                out.close();
            }

      
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PatientRep.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(PatientRep.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PatientRep.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(PatientRep.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
