
import Database.DBQuery;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Doctor_Login", urlPatterns = {"/Doctor_Login"})
public class Doctor_Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession();

       



            try {
                String id = request.getParameter("name").toString();
                System.out.println("Doctor ID = " + id);
          
               
                String pass = request.getParameter("password").toString();
                System.out.println("Doctor Password = " + pass);

                DBQuery db = new DBQuery();
                String hid = db.validatePass(id, pass);
                System.out.println("------------------" + hid);
                if (!hid.equals("")) {
                 
                   
                        System.out.println("Login Successful");
                        session.setAttribute("hid", hid);
                        session.setAttribute("did", id);
                        RequestDispatcher rd=request.getRequestDispatcher("doctor_home.jsp");
                        rd.forward(request, response);
                        //response.sendRedirect("PatientRepID.jsp?doc_id=" + id);
                    } else {
                       
                        response.sendRedirect("doctor_login.jsp");
                    }
             
            } finally {
                out.close();
            }
      
    }

    private static String getClientIp(HttpServletRequest request) {

        String remoteAddr = "";

        if (request != null) {
            remoteAddr = request.getHeader("X-FORWARDED-FOR");
            if (remoteAddr == null || "".equals(remoteAddr)) {
                remoteAddr = request.getRemoteAddr();
            }
        }

        return remoteAddr;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Doctor_Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Doctor_Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
