/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author sumit
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class RunBatFile {

    public static void main(String[] args) {

        ProcessBuilder processBuilder = new ProcessBuilder(info.path_ipfs+"test.bat");
       
        //Process process = Runtime.getRuntime().exec(
        //            "cmd /c hello.bat", null, new File("C:\\Users\\mkyong\\"));
                    
        try {
  File dir = new File(info.path_ipfs);
                        ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/C", "Start","test.bat");
                        pb.directory(dir);
                        Process process = pb.start();
            //Process process = processBuilder.start();

            StringBuilder output = new StringBuilder();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(">>"+line);
                output.append(line + "\n");
            }

            int exitVal = process.waitFor();
            System.out.println("exitVal="+exitVal);
            if (exitVal == 0) {
                System.out.println(output);
                System.exit(0);
            } else {
                //abnormal...
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
