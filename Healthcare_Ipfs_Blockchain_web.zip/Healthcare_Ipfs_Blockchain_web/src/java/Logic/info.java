/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author sumit
 */
public class info {

   public static     String path="E:/2024/Healthcare_Ipfs_Blockchain_web/web/";
    public static     String path_ipfs= "I:/go-ipfs/";                    

    public static     String path_ether="E:/2024/medical_ipfs/";
    public static     String path_py="E:/2024/medical_ipfs/";
    public static     String pname="Healthcare using Blockchain";
    

}
