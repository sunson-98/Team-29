/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sumit
 */
public class ipfs_test {
    public static void main(String[] args) {
        ipfs_test ip=new ipfs_test();
        ip.add_file_ipfs("C:/Users/sumit/Desktop/Ipfs/","music_fog.sql");
    }
    
    
    public void add_file_ipfs(String path,String fname)
    {
        FileOutputStream fout=null;
        try {
            String data="ipfs add "+fname;
            File f=new File(path+"b.bat");
            fout = new FileOutputStream(f);
            fout.write(data.getBytes());
            fout.close();
            
            
            try {
            String[] command = {"cmd.exe", "/C", "Start", path+"b.bat"};
            Process p =  Runtime.getRuntime().exec(command);           
        } catch (IOException ex) {
        }
            
            
//            String line;
//Process p = Runtime.getRuntime().exec("cmd /c start b.bat");
//BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
//while ((line = input.readLine()) != null) {
//    System.out.println(line);
//}
//input.close();
//            
//            ProcessBuilder processBuilder = new ProcessBuilder(path+"a.bat");
//       
//       
//                    
//        try {
//
//            Process process = processBuilder.start();
//
//            StringBuilder output = new StringBuilder();
//
//            BufferedReader reader = new BufferedReader(
//                    new InputStreamReader(process.getInputStream()));
//
//            String line;
//            while ((line = reader.readLine()) != null) {
//                output.append(line + "\n");
//            }
//
//            int exitVal = process.waitFor();
//            if (exitVal == 0) {
//                System.out.println(output);
//                System.exit(0);
//            } else {
//                //abnormal...
//            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//            
//            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
//            ProcessBuilder pb = new ProcessBuilder();//path+"a.bat"
//            String[] c1 = {data};
//            pb.command(c1);
//            pb.directory(new File(path));
//            File outputFile = new File(path+"PingLog.txt");
//            pb.redirectOutput(outputFile);
//            Process process = pb.start();
//                   
//            int exitValue = process.waitFor();
//            System.out.println("Status= "+exitValue);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                fout.close();
            } catch (IOException ex) {
                Logger.getLogger(ipfs_test.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
   
    
    }
}
