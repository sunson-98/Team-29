#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import ipfshttpclient 
import os
from pathlib import Path
from web3 import Web3
import json

path=Path()
client=ipfshttpclient.connect('/ip4/127.0.0.1/tcp/5001/http')
print(client)
url = "http://localhost:7545"
web3 = Web3(Web3.HTTPProvider(url))
print(web3.isConnected())
web3.eth.defaultAccount = web3.eth.accounts[0]
address=web3.toChecksumAddress('0xbFc23f25ECC4306FB39C67E1A1c4AE2fbf522037')
abi = json.loads('[{"constant":true,"inputs":[],"name":"get_data","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_name","type":"string"}],"name":"set_data","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"data","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"}]')
contract = web3.eth.contract(address=address, abi=abi)


# In[ ]:


while True:
    f=open('status.txt','r')
    status=f.read()
    f.close()
    if status!='':
        
        for file in path.glob('*.pdf'):
            print(file)
            if Path(file).is_file():
                print ("File exist")
                res=client.add(file)
                print(res)
                print(res['Name'])
                print(res['Hash'])
                print(res['Size'])
                os.remove(file)
                hash_fname=status+"_hash.txt"
                print("read",hash_fname)
                f=open(hash_fname,'r')
                fhash=f.read()
                f.close()
                
                
                
                
                blk_info=status+"##@@"+fhash+"##@@"+res['Hash']+'##@@'+res['Size']
                print(blk_info)
                
                chain_data=contract.functions.get_data().call()
                print("old data",chain_data)
                new_data=chain_data+"%%@@"+blk_info
                resp = contract.functions.set_data(new_data).transact()
                web3.eth.waitForTransactionReceipt(resp)
                print('resp=',resp)
                f=open('status.txt','w')
                f.write('')
                f.close()
                os.remove(hash_fname)


# In[ ]:




