#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import ipfshttpclient 
import os
from pathlib import Path
from web3 import Web3
import json

path1=Path()
client1=ipfshttpclient.connect('/ip4/127.0.0.1/tcp/5001/http')
print(client1)
url1 = "http://localhost:7545"
web31 = Web3(Web3.HTTPProvider(url1))
print(web31.isConnected())
web31.eth.defaultAccount = web31.eth.accounts[0]
address1=web31.toChecksumAddress('0xbFc23f25ECC4306FB39C67E1A1c4AE2fbf522037')
abi1 = json.loads('[{"constant":true,"inputs":[],"name":"get_data","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_name","type":"string"}],"name":"set_data","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"data","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"}]')
contract1 = web31.eth.contract(address=address1, abi=abi1)


# In[ ]:


while True:
    f1=open('get.txt','r')
    status1=f1.read()
    f1.close()
    if status1!='':
        rid1=status1
        print('rid1',rid1)
        chain_data1=contract1.functions.get_data().call()
        print("old data",chain_data1)
        l=chain_data1.split('%%@@')
        print('l',l)
        
        for c in range(len(l)):
            x=l[c]
            
            print('x',x)
            l1=x.split('##@@')
            if str(l1[0]).startswith(rid1):
                fname1=l1[0]+"_enc.pdf"
                print('fname1',fname1)
                fhash1=l1[1]
                ipfs_hash1=l1[2]
                fsize1=l1[3]
                print(fname1,fhash1,ipfs_hash1,fsize1)
                getfile1=client1.cat(ipfs_hash1)
                f = open(fname1, "wb")
                f.write(getfile1)
                f.close()
                f=open(fname1+".txt",'w')
                f.write(fhash1)
                f.close()
            c=c+1
        f=open('download_status.txt','w')
        f.write('done')
        f.close()
        f=open('get.txt','w')
        f.write('')
        f.close()


# In[ ]:




